from __future__ import annotations

import re
from typing import Any, Dict

import discord

from plugins.settings.registry import FeatureAction, SettingFeature
from plugins.exp import api as exp_api

from plugins.exp.exp import _ExpPreviewView
PACK_META = {
    "id": "exp",
    "name": "Experience",
    "version": "A.37",
    "description": "Server EXP system settings and tools.",
    "category": "Progression",
    "category_description": "Leveling, EXP, ranks, and progression systems.",
}


def _clamp_int(val: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, int(val)))


def _extract_user_id(raw: str) -> int:
    # Accept: 123, <@123>, <@!123>
    digits = re.sub(r"\D+", "", raw or "")
    if not digits:
        raise ValueError("Missing user id")
    return int(digits)


class _ActivityConfigModal(discord.ui.Modal):
    def __init__(self, *, title: str, guild_id: int, kind: str, cfg: Dict[str, Any]):
        super().__init__(title=title)
        self._guild_id = guild_id
        self._kind = kind  # "msg" or "react"
        if kind == "msg":
            enabled = int(bool(cfg.get("msg_enabled", True)))
            xp = int(cfg.get("msg_xp", 15))
            cd = int(cfg.get("msg_cooldown", 60))
            self._keys = ("msg_enabled", "msg_xp", "msg_cooldown")
        else:
            enabled = int(bool(cfg.get("react_enabled", True)))
            xp = int(cfg.get("react_xp", 5))
            cd = int(cfg.get("react_cooldown", 30))
            self._keys = ("react_enabled", "react_xp", "react_cooldown")

        self.enabled_input = discord.ui.TextInput(
            label="Enabled (1=ON, 0=OFF)",
            default=str(_clamp_int(enabled, 0, 1)),
            required=True,
            max_length=1,
        )
        self.xp_input = discord.ui.TextInput(
            label="XP per activity (1-500)",
            default=str(_clamp_int(xp, 1, 500)),
            required=True,
            max_length=4,
        )
        self.cooldown_input = discord.ui.TextInput(
            label="Cooldown seconds (0-3600)",
            default=str(_clamp_int(cd, 0, 3600)),
            required=True,
            max_length=4,
        )

        self.add_item(self.enabled_input)
        self.add_item(self.xp_input)
        self.add_item(self.cooldown_input)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        try:
            enabled = _clamp_int(int(str(self.enabled_input.value).strip()), 0, 1)
            xp = _clamp_int(int(str(self.xp_input.value).strip()), 1, 500)
            cd = _clamp_int(int(str(self.cooldown_input.value).strip()), 0, 3600)

            k_enabled, k_xp, k_cd = self._keys
            await exp_api.set_config_field(self._guild_id, k_enabled, bool(enabled))
            await exp_api.set_config_field(self._guild_id, k_xp, int(xp))
            await exp_api.set_config_field(self._guild_id, k_cd, int(cd))

            await interaction.response.send_message(
                f"Saved {self._kind} settings: enabled={enabled} xp={xp} cooldown={cd}s",
                ephemeral=True,
            )
        except Exception as e:
            await interaction.response.send_message(f"Failed to save settings: {e}", ephemeral=True)



class _UserManageModal(discord.ui.Modal):
    def __init__(self, *, title: str, guild_id: int):
        super().__init__(title=title)
        self._guild_id = guild_id

        self.user_input = discord.ui.TextInput(
            label="User (ID or mention)",
            placeholder="1234567890 or @user",
            required=True,
            max_length=32,
        )
        self.action_input = discord.ui.TextInput(
            label="Action (add/remove/set/reset)",
            placeholder="add | remove | set | reset",
            required=True,
            max_length=10,
        )
        self.value_input = discord.ui.TextInput(
            label="Value (required for add/remove/set)",
            placeholder="Number of XP (e.g., 50)",
            required=False,
            max_length=8,
        )

        self.add_item(self.user_input)
        self.add_item(self.action_input)
        self.add_item(self.value_input)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        try:
            uid = _extract_user_id(str(self.user_input.value))
            action = str(self.action_input.value or "").strip().lower()

            if action not in {"add", "remove", "set", "reset"}:
                await interaction.response.send_message(
                    "Invalid action. Use: add, remove, set, reset.",
                    ephemeral=True,
                )
                return

            if action == "reset":
                prof = await exp_api.reset_profile(self._guild_id, uid)
                await interaction.response.send_message(
                    f"Reset XP for {uid}: xp={prof.xp} level={prof.level}",
                    ephemeral=True,
                )
                return

            raw_val = str(self.value_input.value or "").strip()
            if not raw_val:
                await interaction.response.send_message(
                    "Value is required for add/remove/set.",
                    ephemeral=True,
                )
                return

            val = int(raw_val)

            if action == "add":
                prof = await exp_api.adjust_xp(self._guild_id, uid, abs(val))
                await interaction.response.send_message(
                    f"Added XP for {uid}: xp={prof.xp} level={prof.level}",
                    ephemeral=True,
                )
                return

            if action == "remove":
                prof = await exp_api.adjust_xp(self._guild_id, uid, -abs(val))
                await interaction.response.send_message(
                    f"Removed XP for {uid}: xp={prof.xp} level={prof.level}",
                    ephemeral=True,
                )
                return

            # set
            prof = await exp_api.set_xp(self._guild_id, uid, val)
            await interaction.response.send_message(
                f"Set XP for {uid}: xp={prof.xp} level={prof.level}",
                ephemeral=True,
            )
        except Exception as e:
            await interaction.response.send_message(f"Failed: {e}", ephemeral=True)


async def _handle_exp(interaction: discord.Interaction, payload: Dict[str, Any]):
    if interaction.guild_id is None:
        return {"op": "respond", "payload": {"content": "EXP settings require a server.", "ephemeral": True}}

    gid = int(interaction.guild_id)
    action = (payload or {}).get("action")

    if action == "cfg_msg":
        cfg = await exp_api.get_config(gid)
        return {"op": "modal", "modal": _ActivityConfigModal(title="Messages XP", guild_id=gid, kind="msg", cfg=cfg)}

    if action == "cfg_react":
        cfg = await exp_api.get_config(gid)
        return {"op": "modal", "modal": _ActivityConfigModal(title="Reactions XP", guild_id=gid, kind="react", cfg=cfg)}

    if action == "cfg_voice":
        return {"op": "modal", "modal": _ExpVoiceConfigModal(exp_api, gid)}

    if action == "admin_manage":
        return {"op": "modal", "modal": _UserManageModal(title="Manage User XP", guild_id=gid)}


    if action == "preview":
        # Ephemeral interactive preview for the EXP profile embed/progress bar.
        states = [
            (0, 0, 100),
            (1, 25, 75),
            (5, 450, 50),
            (10, 900, 100),
            (25, 2400, 600),
            (50, 9000, 1000),
            (75, 18000, 2000),
            (100, 50000, 5000),
        ]
        preview = _ExpPreviewView(owner_id=int(interaction.user.id), states=states)
        embed = preview._embed(interaction)
        return {"op": "respond", "payload": {"embed": embed, "view": preview, "ephemeral": True}}
    # Main enable/disable toggle (no other enable/disable toggles on this page)
    cfg = await exp_api.get_config(gid)
    cur = bool(cfg.get("enabled", True))
    new_state = (not cur)
    await exp_api.set_config_field(gid, "enabled", new_state)
    # No confirmation message: UI toggle state is the confirmation.
    return {"op": "toggle", "is_on": bool(new_state)}


class _ExpVoiceConfigModal(discord.ui.Modal, title="Voice XP Settings"):
    enabled = discord.ui.TextInput(label="Voice XP enabled", default="true", required=True, max_length=5)
    xp = discord.ui.TextInput(label="XP per interval", default="8", required=True, max_length=6)
    tick = discord.ui.TextInput(label="Interval seconds", default="300", required=True, max_length=8)

    def __init__(self, api: ExpApi, guild_id: int):
        super().__init__()
        self._api = api
        self._guild_id = guild_id

    async def on_submit(self, interaction: discord.Interaction):
        def _to_bool(s: str) -> bool:
            return s.strip().lower() in {"1", "true", "yes", "y", "on"}

        try:
            enabled = _to_bool(str(self.enabled.value))
            xp = int(str(self.xp.value).strip())
            tick = int(str(self.tick.value).strip())
        except Exception:
            await interaction.response.send_message("Invalid input. Expected booleans/integers.", ephemeral=True)
            return

        xp = max(0, min(10_000, xp))
        tick = max(0, min(86_400, tick))

        await self._api.set_config_field(self._guild_id, "voice_enabled", bool(enabled))
        await self._api.set_config_field(self._guild_id, "voice_xp", xp)
        await self._api.set_config_field(self._guild_id, "voice_tick", tick)

        await interaction.response.send_message("Voice XP settings updated.", ephemeral=True)


async def setup(bot, registry):
    registry.register(
        SettingFeature(
            feature_id=PACK_META["id"],
            label=PACK_META["name"],
            description=PACK_META["description"],
            category=PACK_META["category"],
            category_description=PACK_META["category_description"],
            handler=_handle_exp,
            actions=[
                FeatureAction("cfg_msg", "Configure Messages XP", "Tune XP per message and cooldown to prevent spam leveling.", style="secondary", row=1),
                FeatureAction("cfg_react", "Configure Reactions XP", "Tune XP for reactions (adds) and any cooldown/limits.", style="secondary", row=1),
                FeatureAction("cfg_voice", "Configure Voice XP", "Set voice XP: earn XP every 'tick' seconds while connected (e.g., 300s = 5 min).", style="secondary", row=1),
                FeatureAction("admin_manage", "Manage User XP", "Admin tools: add/remove/set a user's XP.", style="primary", row=2),
                FeatureAction("preview", "Preview EXP Card", "Interactive preview of the /exp profile embed across multiple levels.", style="secondary", row=2),
            ],
        )
    )


async def teardown(bot, registry):
    registry.unregister(PACK_META["id"])
